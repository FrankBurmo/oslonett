#!/local/bin/perl5

#--------------------------------------------------------------------------------
#
# TOOLS.CGI - program som implementerer en ferdig l�sning for oppdatering og 
#             vedlikehold av InterShop's produktdatabase. 
#
#             Programmet tar et antall parametre, som kontrollerer hva som skal
#             skje av oppdateringer, listinger, fjerning av produkter osv. osv. 
#
#             Disse er spesifisert nedenfor:
#
#             Ved kall fra et html-dokument, benytter man tools.cgi?<parametere>
#             Slik antyder man hva man �nsker som neste skjermbilde.
#
#             Inputs via forms er ogs� st�ttet. Denne input parses og legges i
#             en assosiativ array, slik den er lett � hente frem fra de ulike
#             delene i programmet.
#
# PARAMETRE:
#             produkt - vi �nsker � gj�re noe med et produkt i produktbasen
#                       Eksempel: tools.cgi?produkt&fjern&prod_id
#                                 tools.cgi?produkt&ny
#                                 tools.cgi?produkt&endre
#                                 tools.cgi?produkt&oversikt
#
#             avdeling - vi �nsker � gj�re noe med en avdeling i avdelingsbasen
#                        virker p� tilsvarende m�te som for produkt, med de samme
#                        tilleggsparameterne. 
#
#             fastside - endring(er) p� "faste" sider, som nyheter, forside o.l.
#
#             
# (c) 1995 Kent Vilhelmsen, Shibsted Nett, All Rights Reserved
#--------------------------------------------------------------------------------

# Loggfiler som holder oversikt over oppdateringer i produktdatabasen og avd.basen
$CONTLOG = "prodbase.log";
$AVDLOG  = "avdbase.log";
$INDEX_ROOT="/local/www/sh/is/";
$PROD_FILE = $INDEX_ROOT . "katalog/pb.txt";
$AVD_FILE  = $INDEX_ROOT . "katalog/ab.txt";

$CONT_UPDATED = "unknown";      

#open(STDERR, "/dev/null");

#
# Analyser input/parametre

$produkt = $avdeling = $fastside =0;
$endre = $fjern = $ny = $oversikt = 0;

@PARAMS = split(/\&/,$ENV{'QUERY_STRING'});

# Hva dreier det seg om? produkt? avdeling? osv. 
$produkt  = 1 if $PARAMS[0] eq "produkt";
$avdeling = 1 if $PARAMS[0] eq "avdeling";
$fastside = 1 if $PARAMS[0] eq "fastside";

# Aksjonen som skal utf�res finner vi her
$endre    = 1 if $PARAMS[1] eq "endre";
$fjern    = 1 if $PARAMS[1] eq "fjern";
$ny       = 1 if $PARAMS[1] eq "ny";
$oversikt = 1 if $PARAMS[1] eq "oversikt";

# Diverse "underniv�er"
$update   = 1 if $PARAMS[2] eq "update";
$undo = 1 if $PARAMS[2] eq "undo";
$soek = 1 if $PARAMS[2] eq "soek";

$go = 1 if ($update == 1 && $PARAMS[3] eq "go");

# Eventuelle parametre, som f.eks. hvilket produkt som skal fjernes
$param    = $PARAMS[$#PARAMS];

# Sjekk om vi har f�tt noe data fra forms
&ReadParse;

# Les avd. og katalogfiler
&ReadAvdProd;

# OK, da setter vi i gang, for�vrig en ELENDING m�te � gj�re dette p�...

if ($produkt && $ny) {
    if ($update == 1) {
	&prod_update;
    } else {
	&NyttProdukt;
    }
}

if ($produkt && $endre) {
    if ($update == 1) {
	if ($go == 1) {
            &prod_update;
        } else {
            &endreprodukt_update;
        }
    } else {
	&EndreProdukt;
    }
}

if ($produkt && $fjern) {
    if ($update == 1) {
	&fjernprodukt_update;
    } elsif ($undo == 1) {
	&undo_dbendring;
    } else {
	&FjernProdukt;
    }
}

if ($produkt && $oversikt) {
    if ($soek ==1 ) {

	&produktsoek;
    } else {
	&ProduktOversikt;
    }
}


&write_footer;

exit(0);


#--------------------------------------------------
# ProduktOversikt
#--------------------------------------------------
sub ProduktOversikt {
    &write_header("Produktoversikt");

    print qq! 
<p>
<font size=+1>
<a href="tools.cgi?produkt&ny">[Nytt Produkt]</a>
<a href="tools.cgi?produkt&endre">[Endre Produkt] </a>
<a href="index.cgi">[Hovedside]</a>
</font>

<p>
<blockquote>
<form method="POST" action="tools.cgi?produkt&oversikt&soek">
<font size=+1>Tast inn s�kebegrep:</font><br>
<input size=40 name="soekebegrep">
<input type="SUBMIT" value="Utf�r"><input type="RESET" value="Reset">
<br><b>Eksempler:</b> IBM, Apple, 1.1.3 (kategori) etc. Hvis du vil se alle, la feltet st� �pent.<p>
</form>
<pre>

</pre>
    !;				


    return;
}

#--------------------------------------------------
# produktsoek
#--------------------------------------------------
sub produktsoek {
    local(@TMP);
    &write_header("Produktoversikt - resultat av s�k");

    print qq! 
<p>
<font size=+1>
<a href="tools.cgi?produkt&ny">[Nytt Produkt]</a>
<a href="tools.cgi?produkt&endre">[Endre Produkt] </a>
<a href="index.cgi">[Hovedside]</a>
</font>
<p>
    !;			 
    print "<font size=+1>\n";
    foreach $_ (@PROD_LIST) {
	if (/$in{'soekebegrep'}/) {
	    @TMP = split(/\#/, $_);
	    print "<a href=\"tools.cgi?produkt&endre&update&$TMP[0]\">$TMP[0]</a>\#$TMP[1]";
	    print "</font><br>";
	}
    }
    return;
}


#--------------------------------------------------
# FjernProdukt
#--------------------------------------------------
sub FjernProdukt {
    &write_header("Fjern et produkt");

    print qq! 

<p>
<font size=+1>
<a href="tools.cgi?produkt&ny">[Nytt Produkt]</a>
<a href="tools.cgi?produkt&endre">[Endre Produkt] </a>
<a href="index.cgi">[Hovedside]</a>
</font>
<p>
<blockquote>
<form method="POST" action="tools.cgi?produkt&fjern&update">
<font size=+1>Tast inn kategorinummer og varenummer(e), separert med .-tegn.</font><br>
<input size=40 name="produkter">
<input type="SUBMIT" value="Utf�r"><input type="RESET" value="Reset">
<br><b>Eksempler:</b> 1.1.2.30005NO <p>
</form>
<p>
<a href="tools.cgi?produkt&oversikt"><font size=+1>Oversikt over alle produktene</a></font>
</blockquote>
    !;


    return;
}

#--------------------------------------------------
# fjernprodukt_update
#--------------------------------------------------
sub fjernprodukt_update {
    &write_header("Fjerner et produkt");


    print qq!
<p>
<font size=+1>
<a href="tools.cgi?produkt&ny">[Nytt Produkt]</a>
<a href="tools.cgi?produkt&endre">[Endre Produkt] </a>
<a href="index.cgi">[Hovedside]</a>
</font>
<p>
    !;		


    for ($line=0; $line <= $#PROD_LIST; ++$line) {
	$_ = $PROD_LIST[$line];

	if (/^$in{'produkter'}\#/) {
	    # Vi fant det. Oppdater.
	    print "<font size=+1><b>F�lgende produkt er slettet:</b></font>\n";
	    &skriv_prod_linje($PROD_LIST[$line]);
	    splice(@PROD_LIST, $line, 1);

	    &save_prodbase;


	    print qq!
<p>
<font size=+1><b>Hvis du angrer slettingen, <a href="tools.cgi?produkt&fjern&undo"> trykk her.</a></FONT></B>

<pre>



</pre>
    !;

	    return;
	}
    }
    error("Fant ikke data!") if $#LINE < 2;



    return;
}



#--------------------------------------------------
# undo_dbendring - kopierer tilbake backup-kopien
#--------------------------------------------------
sub undo_dbendring {
    &write_header("Siste oppdatering av basen er fjernet");

    $PFB = $PROD_FILE . ".bak";
    system ("cp $PFB $PROD_FILE"); system("chmod 775 $PFB");

    print qq! 

<p>
<font size=+1>
<a href="tools.cgi?produkt&ny">[Nytt Produkt]</a>
<a href="tools.cgi?produkt&endre">[Endre Produkt] </a>
<a href="index.cgi">[Hovedside]</a>
</font>
<p>
    !;

    return;
}


#--------------------------------------------------
# NyttProdukt
#--------------------------------------------------
sub NyttProdukt {

    &write_header("Legg til nytt produkt");

    print qq!

<hr size=1 noshade>
<font size=+1>Her kan du legge inn nye produkter.N�r du er forn�yd, trykker du p� "Oppdater", og basen vil oppdateres. Evt. problemer vil rapporteres. For hver oppdatering lages en sikkerhetskopi av databasen. Den tidligere produktbasen kan dermed legges tilbake hvis man ikke oppdager feil f�r det er for sent. Angrefunksjonen er tilgjengelig fra forsiden.
<hr size=1 noshade><p>
<form method="POST" action="tools.cgi?produkt&ny&update">
<pre>
<font size="+1"><b>Kategorinummer:</b></font> <input size=10 name="kat"> <font size=+1><b>Produktnummer:</b></font> <input size="12" name="prodnr">
<font size="+1"><b>Produktnavn:</b>    <input size="40" name="navn">
<b>Pris:</b></font>           <input size="10" name="pris">  
<font size=+1><b>Evt. gif-bilde</b></font>  <input size="20" name="gif"><p>
<font size=+1><b>Evt. produktbeskrivelse</b> (gjerne med HTML-koder)</font>
<textarea rows=3 cols=70 name="beskr"></textarea>

</pre>
<input type="SUBMIT" value="Oppdater"> <input type="RESET" value="Reset">
</form>

!;


    return;
}



#--------------------------------------------------
# EndreProdukt - tast inn kategori og produktnummer
# derefter endres produktet via endreprodukt_i_forms
#--------------------------------------------------
sub EndreProdukt {
    &write_header("Endre Produkt");

    print qq! 
<blockquote>
<form method="POST" action="tools.cgi?produkt&endre&update">
<font size=+1>Tast inn kategorinummer og varenummer, separert med . (punktum).</font><br>
<input size=40 name="produkter">
<input type="SUBMIT" value="Utf�r"><input type="RESET" value="Reset">
<br><b>Eksempler:</b> 1.1.2.30005NO <p>
</form>
<p>
<a href="tools.cgi?produkt&oversikt"><font size=+1>Oversikt over alle produktene</a></font>
</blockquote>
    !;


    return;
}


#--------------------------------------------------
# endreprodukt_i_forms
#--------------------------------------------------
sub endreprodukt_update {
    
    &write_header("Endre et produkt");

    # Enten har vi f�tt koden for hvilket produkt vi skal endre via et forms,
    # eller s� er det lagt med som parameter (ved direktevalg fra liste)

    $in{'produkter'} = $params if $in{'produkter'} eq "";

    foreach (@PROD_LIST) {
	if (/^$in{'produkter'}\#/) {
	    @LINE = split(/\#/,$_);
	    $in{'kat'} = $1 if $in{'produkter'} =~ /^(\d+(\.\d+)*)\./;
	    $in{'prodnr'} = $1 if $in{'produkter'} =~ /^[\d+|\.]*\.(.*)$/;
	    }		    
    }
    
    error("Fant ikke data!") if $#LINE < 2;

    print qq!

<hr size=1 noshade>
<font size=+1>Her kan du endre et produkt.N�r du er forn�yd, trykker du p� "Oppdater", og basen vil oppdateres. Evt. problemer vil rapporteres. For hver oppdatering lages en sikkerhetskopi av databasen. Den tidligere produktbasen kan dermed legges tilbake hvis man ikke oppdager feil f�r det er for sent. Angrefunksjonen er tilgjengelig fra forsiden.
<hr size=1 noshade><p>
<form method="POST" action="tools.cgi?produkt&endre&update&go">
<pre>
<font size="+1"><b>Kategorinummer:</b></font> <input size=10 name="kat" value=$in{'kat'}> <font size=+1><b>Produktnummer:</b></font> <input size="12" name="prodnr" value=$in{'prodnr'}>
<font size="+1"><b>Produktnavn:</b>    <input size="40" name="navn" value=$LINE[1]>
<b>Pris:</b></font>           <input size="10" name="pris" value=$LINE[2]>  
<font size=+1><b>Evt. gif-bilde</b></font>  <input size="20" name="gif" value=$LINE[3]><p>
<font size=+1><b>Evt. produktbeskrivelse</b> (gjerne med HTML-koder)</font>
<textarea rows=3 cols=70 name="beskr" value=$LINE[4]></textarea>

</pre>
<input type="SUBMIT" value="Oppdater"> <input type="RESET" value="Reset">
</form>

!;

    return;
}



#--------------------------------------------------
# prod_update
#--------------------------------------------------
sub prod_update {

    &write_header("Endre produkt - Nytt produkt");

	    print qq!
<p>
<font size=+1>
<a href="tools.cgi?produkt&ny">[Nytt Produkt]</a>
<a href="tools.cgi?produkt&endre">[Endre Produkt] </a>
<a href="index.cgi">[Hovedside]</a>
</font>
<p>
    !;		

    # Vi skal legge til et produkt eller endre et produkt
    # 1. Sjekk at vi har nok info

    &error ("Vi m� ha et kategorinummer!") if $in{'kat'} eq "";

    $tmp     = "\#" . $in{'gif'} . "\#" . $in{'beskr'};
    $tmp = "" if $tmp eq "\#\#";

    $nylinje =$in{'kat'} . "." . $in{'prodnr'} . "\#" . $in{'navn'} . "\#" . $in{'pris'} . $tmp;


    # 2. Sjekk om vi har oppdatering eller nytt produkt. 

    for ($line=0; $line <= $#PROD_LIST; ++$line) {
	$_ = $PROD_LIST[$line];

	if (/^$in{'kat'}\.$in{'prodnr'}\#/) {
	    # Vi fant det. Oppdater.
	    print "<font size=+1><b>Produktet ligger allerede i basen:</b></font>\n";
	    print "<p><pre><font size=+1>$PROD_LIST[$line]</font></pre>\n";
	    print "<p><font size=+1><b>Endret til:</b></font>\n";
	    print "<p><pre><font size=+1>$nylinje</font></pre>\n";

	    &skriv_prod_linje($nylinje);
	    $PROD_LIST[$line] = $nylinje;
	    
	    &save_prodbase;
	    &angre_knapp;

	    return;
	}
    }

    # Legg til en linje i basen. Finn f�rst ut hvor vi vil ha den. 
    for ($line=0; $line <= $#PROD_LIST; ++$line) {
	$_ = $PROD_LIST[$line];
	if (/^$in{'kat'}/) {
	    #OK, legg inn linje.
	    print "<font size=+1><b>La til ny linje:<br></b></font>";
	    print "<pre>$nylinje</pre>";
	    splice(@PROD_LIST, $line, 0, $nylinje, $PROD_LIST[$line]);
	    &save_prodbase;
	    &angre_knapp;

	    return;
	}
    }

    &error("Ingen endringer gjort i basen!");
    return;
}


#--------------------------------------------------
# angre_knapp 
#--------------------------------------------------
sub angre_knapp {
    
    print qq!
<p>
<font size=+1><b>Hvis du angrer slettingen, <a href="tools.cgi?produkt&fjern&undo"> trykk her.</a></FONT></B>
    !;

    return;
}

#--------------------------------------------------
# Skriver ut en produktlinje. Benyttes av flere
# prosedyrer for interaktivitet mellom bruker. 
#--------------------------------------------------
sub skriv_prod_linje {
    local($linje) = @_;
    local(@TMP);
    @TMP = split(/\#/,$linje);

    print qq!
<table border=1 cellspacing=5 cellpadding=0 width=80%>
<tr>
<td valign=top><font size=+1><b>Kategori \& Prod.nr.</b></font></td>
<td valign=top><font size=+1><b>Navn</b></font></td>
<td valign=top><font size=+1><b>Pris</b></font></td>
<td valign=top><font size=+1><b>Gif</b></font></td>
</tr>
<tr>
<td valign=top>$TMP[0]</td>
<td valign=top>$TMP[1]</td>
<td valign=top>$TMP[2]</td>
<td valign=top>$TMP[3]</td>
</tr>
<tr>
<td valign=top align=left colspan=4>
<font size=+1><b>Beskrivelsestekst:</b></font><br>
$TMP[5]
</td>
</tr>
</table>
	!;
    return;
}

#--------------------------------------------------
# save_prodbase - lagrer produktbasen, tar f�rst
# backup av gammel base.
#--------------------------------------------------
sub save_prodbase {
    # Lag f�rst en backupfi
    $PFB = $PROD_FILE . ".bak";
    system ("cp $PROD_FILE $PFB"); system("chmod 775 $PFB");

    # Skriv ut PROD_FILE
    open(PROD, ">$PROD_FILE") || error ("Kunne ikke skrive til produktfilen!");
    foreach $l (@PROD_LIST) {
	$l=~ s/\s//g;
	print PROD "$l\$\$\n" if $l ne "####";
    }

    close(PROD);
    return;
}



#--------------------------------------------------
# save_avdbase - lagrer avdelingsdatabasen, tar f�rst
# backup av gammel base
#--------------------------------------------------
sub save_avdbase {
    # Lag f�rst en backupfi
    $AB = $AVD_FILE . ".bak";
    system ("cp $AVD_FILE $AB"); system("chmod 775 $AB");

    # Skriv ut AVD_FILE
    open(AFIL, ">$AVD_FILE") || error ("Kunne ikke skrive til produktfilen!");
    foreach $l (@AVD) {
	$l=~ s/\s//g;
	print AVD_FILE "$l\$\$\n";
    }

    close(AFIL);
    return;
}



#--------------------------------------------------
# Les inn avdelings- og katalogfilene
#--------------------------------------------------
sub ReadAvdProd {

    open(AFIL,"<$AVD_FILE") || error("Not able to open $AVD_FILE\n");
    @TMP_AVD = <AFIL>;
    @AVD = ();
    $count=0;
# Les gjennom kategori/avdelingsfilen for � sjekke om noen linjer m� sl�s sammen
    foreach (@TMP_AVD) {
	next if /^\s*$/;
	# Alle linjer skal slutte med $$. Hvis ikke, sl� sammen denne og (de) neste
	# linje(r), til vi f�r avsluttet med $$.
	if (!/.*\$\$$/) {
	    $in=$in.$_;
	    next;
	}
	s/\$\$//;
	$in=$in.$_;
	$AVD[$count++] = $in;
	$in = "";                      
    }
    
    open(PROD, "<$PROD_FILE") || error("Fikk ikke �pnet produktdatabasen");
    @TMP_PROD = <PROD>;
    @PROD_LIST = ();
    $count=0;
    foreach (@TMP_PROD) {
	next if /^\s*$/;
	# Alle linjer skal slutte med $$. Hvis ikke, sl� sammen denne og (de) neste
	# linje(r), til vi f�r avsluttet med $$.
	if (!/.*\$\$$/) {
	    $in=$in.$_;
	    next;
	}
	s/\$\$//;
	$in=$in.$_;
	$PROD_LIST[$count++] = $in;
	$in = "";                      
    }

    close(AFIL);
    close(PROD);

}

#--------------------------------------------------
# formater input fra evt. forms
#--------------------------------------------------
sub ReadParse {
  if (@_) {
    local (*in) = @_;
  }

  local ($i, $loc, $key, $val);

  # Read in text
  if ($ENV{'REQUEST_METHOD'} eq "GET") {
    $in = $ENV{'QUERY_STRING'};
  } elsif ($ENV{'REQUEST_METHOD'} eq "POST") {
    for ($i = 0; $i < $ENV{'CONTENT_LENGTH'}; $i++) {
      $in .= getc;
    }
  } 


  @in = split(/&/,$in);

  foreach $i (0 .. $#in) {
    # Convert plus's to spaces
    $in[$i] =~ s/\+/ /g;

    # Convert %XX from hex numbers to alphanumeric
    $in[$i] =~ s/%(..)/pack("c",hex($1))/ge;

    # Split into key and value.
    $loc = index($in[$i],"=");
    $key = substr($in[$i],0,$loc);
    $val = substr($in[$i],$loc+1);
    $in{$key} .= '\0' if (defined($in{$key})); # \0 is the multiple separator
    $in{$key} .= $val;
  }

  return 1; # just for fun
}



#--------------------------------------------------
# write_header - skriver header for HTML-dokument
#--------------------------------------------------
sub write_header {
    local($tittel) = @_;
    print "Content-type: text/html\n\n";
    print qq!
<html>
<head>
<title>
$tittel
</title>
</head>
<body bgcolor=#ffffff>
<hr noshade size=1>
<center>
<h2>$tittel</h2>
</center>
<hr noshade size=1>
<p>
    !;				

    return;
}


#--------------------------------------------------
# write_footer - skriver footer for HTML-dokument
#--------------------------------------------------
sub write_footer {

    print qq!
<hr size=1 noshade>
(C) 1995 Schibsted Nett
<hr size=1 noshade>
</body>
</html>

    !;       

    return;
}


#---------------------------------------------------
# error - behandler feilmelding f.eks. ved filaksess
#---------------------------------------------------
sub error {

    local($_)=@_;

    print qq!

<center><font size=+2> $_ </font></center>
</body>
</html>

!;

        exit(0);
}
