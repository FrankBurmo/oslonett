#!/local/bin/perl


# gencat.cgi
#
# Dag Wigum, 16.11.95
#
# Genererer en htmlfil med annonsene for en kategori
#

$kat_file="resultatdb.txt";


# Neste linje virker kun for method="GET". B�r gi feilmelding hvis dette
# ikke er tilfelle eller bruke read(STDIN, $kat, $ENV{'CONTENT_LENGTH'}
# hvis method="POST".

$kat = $ENV{'QUERY_STRING'};


open(STDERR, "/dev/null");

open(FIL,"<$kat_file") || die "Not able to open $kat_file\n";

dbmopen(%KEYINDEX,"key",0664) || print "Content-type: text/html\n\nFoo";

dbmopen(%MAININDEX,"oppslag",0664) || print "Content-type: text/html\n\nFoo";


# Lag title-tag...

$title = "Aftenposten - Annonser";

# Lag body-tag...
$body_tag = "<body BGCOLOR=\"#ffffee\" TEXT=\"#000000\"
           LINK=\"#0000ff\" VLINK=\"#aa0000\" ALINK=\"#aa0000\">";


&header;
&katalog;
&footer;

sub header {

    print "Content-type: text/html\n\n";

    print "
<html>
<head>
<title>
$title
</title>
</head>

$body_tag

<center>
<!------------------- Standard header -------------------------->     
<A HREF=\"../banner/rubr_u.map\">
<IMG WIDTH=454 HEIGHT=65 ALT=\"Aftenposten - Annonser\" 
SRC=\"../banner/rubr_u.gif\" ISMAP border=0></A><BR><BR>
<h3>$kat ANNONSER</h3>
</center>


";

    return;
}

sub katalog{


    while (defined($KEYINDEX{$i.$kat})) {
	@TMP = split(/,/,$KEYINDEX{$i.$kat});

	foreach $_ (@TMP) {
	    $tmp = $MAININDEX{$_};
	    @FELT = split(/<br>/,$tmp);
	    $funnet="ja";
	    @a = split(/\#/,shift(@FELT));
	    
	    @b=split(/=/,$a[1]);
	    
	    print "<blockquote>";	
	    print "<blockquote>";	
	    print "<b>$b[1]</b><br>";
	    foreach $b (@FELT) {
		print "$b";
	    }
	    print "</blockquote>";
	    print "</blockquote>";
	    print "<hr>";		
	    

	}

	$i++;


	}
    	if ($funnet ne "ja") {
	    print "<center><h2>Ingen Treff</h2></center>";

    }
    return;
}


sub footer {

    print "
<!---- KNAPPERAD + tekstversjon-------->
<center>
<A HREF=\"../banner/rubr_ub.map\">
<IMG SRC=\"../banner/rubr_ub.gif\" ISMAP border=0></A><br><br>
<font size=\"-1\">
<a href=\"../hjemme/innhold.htm\">[Innhold]</a> <a 
href=\"../info/hjelp/xxx.htm\">[Info]</a> <a href=\"/\">[Aftenposten 
hjemmeside]</a> <a href=\"index.htm\">[Annonser hovedside]</a>
</center>
</font>

</body>
</html>

";

    return;
}


dbmclose(%MAININDEX);
dbmclose(%KEYINDEX);
close FIL;


	
