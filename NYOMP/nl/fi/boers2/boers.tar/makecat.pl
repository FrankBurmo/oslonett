#!/local/bin/perl



$kat_file="kategorier.txt";


open(STDERR, "/dev/null");

open(FIL,"<$kat_file") || die "Not able to open $kat_file\n";


dbmopen(%KAT,"kategori",0664) || print "Content-type: text/html\n\nFoo";

	     
$KAT{BANK} = "BSK ,Bergens Skillingsbk. ,300250+BNB ,BNbank ,513940+CKR ,Chr. Bank og Kred. ,302553+DNB ,Den norske Bank ,300200+FOK ,Fokus Bank ,302560+ISB ,Ind. & Skipsbanken ,300500+NBK ,Nordlandsbanken ,301400+NOK ,Norgeskreditt P ,302800+";


dbmclose(%KAT);

close FIL;
	
