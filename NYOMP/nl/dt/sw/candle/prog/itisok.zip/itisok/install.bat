@ECHO OFF
ECHO OFF
ECHO INSTALLASJON AV ITISOK
IF "%1"=="" GOTO NOTOK
IF "%2"=="" GOTO NOTOK
IF "%3"=="" GOTO NOTOK
GOTO OK
:NOTOK
ECHO Du m} skrive f.eks. "INSTALL A: C: \ITISOK", eller bytte en av
ECHO A:, C: eller \ITISOK med noe annet.
GOTO SLUTT
:OK
@ECHO ON
%2
md %3
copy %1\itisok.lzh %3
copy %1\lharc.exe %3
cd %3
lharc x itisok

md cbe
md font
md sms2
md partnere

cd cbe
..\lharc x ..\cbe
cd ..\font
..\lharc x ..\font
cd ..\sms2
..\lharc x ..\sms2
cd ..\partnere
..\lharc x ..\partnere
cd ..

@ECHO ------ INSTALLASJON AV ITISOK FERDIG -------
@ECHO ----- SKRIV "START" FOR � BRUKE ITISOK -----
:NOTOK
