REM HUSK AT DU M� KJ�RE TINY F�RST
pause

del *.bak

lharc a cbe cbe\*.*
lharc a font font\*.*
lharc a sms2 sms2\*.*
lharc a partnere partnere\*.*
lharc a itisok *.*
copy itisok.lzh a:
copy lharc.exe a:
copy install.bat a:

REM MKFLOP FERDIG



