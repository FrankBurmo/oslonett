#!/local/bin/perl5

require "lib.pl";
$SEPARATOR = "\t";
$FILENAME = 'markedsbase.txt';
$INPUTLENGTH = 40;
@SPECFIELDS = ('beskrivelse','forkortelse','searchable','null','alignment');
@SPEC = (
	 'Status	status	meny	ikke-null	<h2>',
	 'Beliggenhet	omr	meny	null	<h2>',
	 'Lokaltype	type	meny	null	<h3>',
	 'Adresse	adr	fritekst	null	v',
	 'Kvadratmeter	kvm	ikke s�kbar	null	h',
	 'Sidetall	side	ikke s�kbar	null	h',
	 'Megler	megler	fritekst	null	v',
	 'Telefon	tel	ikke s�kbar	null	v',
	 );


%input = &getinput;

foreach $i ($[ .. $#SPEC) {
    @field{@SPECFIELDS} = split(/$SEPARATOR/, $SPEC[$i]);
    push(@cols, $field{forkortelse});
    $overskr{$field{forkortelse}} = $field{beskrivelse};
    $null{$field{forkortelse}} = $field{null};
    $search{$field{forkortelse}} = $field{searchable};
    push(@searchable, $field{forkortelse})
	unless $field{searchable} =~ /^ikke/;
    $align{$field{forkortelse}} = $field{alignment};
}
open(FILE, $FILENAME) || &error("Kan ikke �pne markedsdatabasen $FILENAME");

&showform if $input{form};

$input{status} =~ tr/A-Z���/a-z���/;
unless ($input{status} =~ /^(leie|s�kes|selges)$/) {
    &printheader("Markedsoversikten");
    print qq!<font size="+1">\n!;
    print "Du m� angi en av kategoriene nedenfor:\n";
    print "<ul>\n";
    print qq!<li> <a href="$ENV{SCRIPT_NAME}?status=leie">Leie</a>\n!;
    print qq!<li> <a href="$ENV{SCRIPT_NAME}?status=selges">Selges</a>\n!;
    print qq!<li> <a href="$ENV{SCRIPT_NAME}?status=s�kes">S�kes</a>\n!;
    print "</ul>\n";
    &printfooter;
    exit 0;
}

open(BASE, $BASE) || &error("Kan ikke �pne link-databasen $BASE");
while (<BASE>) {
    $link{$1} = $2 if /([^%]+)%(.+)/;
}
close BASE;

&printheader("Markedsoversikten: $input{status}");

$input{status} =~ tr/a-z���/A-Z���/;

print qq!<table border="0">\n!;
LINE:
while (<FILE>) {
    @tmp{@cols} = split(/$SEPARATOR/);
    foreach $key (@searchable) {
	next LINE if length $input{$key} && $tmp{$key} !~ /$input{$key}/i;
    }

    if ($tmp{omr} ne $lastomr) {
	print qq!<tr><th colspan="5" align="center">!;
	print qq!<font size="+2"><b>$tmp{omr}</b></font><br>!;
	print "<em><b>$tmp{type}</b></em></th>\n";
	$lastomr = $tmp{omr};
	$lasttype = $tmp{type};
    } elsif ($tmp{type} ne $lasttype) {
	print qq!<tr><th colspan="5" align="center">!;
	print qq!<em><b>$tmp{type}</b></em></th>!;
	$lasttype = $tmp{type};
    }
    unless ($overskr++) {
	# Skriv ut overskriftene kun �n gang...
	print "<tr><td><em>";
	print join("</em></td><td><em>",
		   @overskr{adr,kvm,side,megler,tel});
	print "</em></td>\n";
    }
    print "<tr>";
    foreach $key ('adr', 'kvm', 'side', 'megler', 'tel') {
	if ($align{$key} =~ /^h/i) {
	    print qq!<td align="right">!;
	} else {
	    print "<td>";
	}
	while (($k,$v) = each %link) {
	    last if $tmp{$key} =~ s!($k)!<a href="$v">$1</a>!;
	}
#	$tmp{$key} = $link{$tmp{$key}} if length $link{$tmp{$key}};
	print "$tmp{$key}</td>\n";
    }
}
print "</table>\n";
close FILE;


&printfooter;

exit 0;


sub showform {
    &printheader("Markedsoversikten: s�k");

    while (<FILE>) {
	@tmp{@cols} = split(/$SEPARATOR/);
	foreach (@searchable) {
	    $count{"$_: $tmp{$_}"}++ if $search{$_} =~ /meny/i;
	}
    }
    close FILE;

    print qq!<form action="$ENV{SCRIPT_NAME}" method="POST">\n!;
    print "<table><dl>\n";
    foreach $c (@cols) {
	next if $search{$c} =~ /^ikke/i;
	print qq!<tr><td><dt><font size="+1">$overskr{$c}: </font></td>\n!;
	print "<td> <dd>";
	if ($search{$c} =~ /^fritekst/i) {
	    print qq!<input name="$c" size="$INPUTLENGTH"><br>\n!;
	} elsif ($search{$c} =~ /^meny/i) {
	    print qq!<select name="$c">\n!;
	    print qq!<option value=""> Vilk�rlig\n! if $null{$c} =~ /^null/;
	    foreach (sort keys %count) {
		next unless s/^$c:\s*//;
		print qq!<option value="$_"> $_\n!;
	    }
	    print "</select><br>\n";
	}
	print "</td>\n",
    }
    print <<EOT;
<tr><td><dt><input type="submit" value=" S�k "></td>
</dl></table>
</form>
EOT

    &printfooter;
    exit 0;
}

