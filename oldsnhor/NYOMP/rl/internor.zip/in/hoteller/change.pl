#!/local/bin/perl

$utfil="./tmpfil.html";
$input1="</body>";
$input2="<a href=\"/rl/in/kart.html\">Tilbake</a> til klikkbart kart.<br><a href=\"/rl/in/hoteller/hotelloversikt.html\">Tilbake</a> til hotelloversikten.</body>";

print "\n Jeg skifter ut $input1 med $input2.\n\n";

open(FIND, "find .  -name \"*.html\" -print |") || 
    die "Kunne ikke kj�re find: $!\n";

$funnet=0;

while ($filename = <FIND>)
{
    #print "$filename \n";
    
    open(INNFIL,"<$filename");
    open(UTFIL,">$utfil")|| die "Kunne ikke aapne $utfil \n";;

    while(<INNFIL>)
    {	
	$linje=$_;
	$_=~ s/$input1/$input2/g;
	print UTFIL;
	if($linje=~ /$input1/)
	{
	    $funnet=1;
	    print "$filename \n";
	}
    }
    close (UTFIL);
    close (INNFIL);
    
    if($funnet==1)
    {
	chop $filename;
	$backup=$filename.".bak";
	print "TEST: $backup\n";
	`cp $filename $backup`;
    }
    `mv $utfil $filename`;
    `chmod g+rxw $filename`;
    `chmod a+rx $filename`;
    
    $funnet=0;

}


