#!/local/bin/perl5


#
# teknisk_support.cgi
#
# Side for teknisk vedlikehold av data i avdelingsdatabase og produktdatabase. 
# Send med filnavn for konfigurasjonsfil som parameter. Husk full path!
#
# Typisk konfigurasjonsfil er intershop.cgf
#
# (c) 1995 Kent Vilhelmsen International Corp. 
#


$path      = $ENV{'PWD'};
$conf_file = $ARGV[0];

open(FIL,"<$conf_file") || die "Not able to open $conf_file\n";
open(STDERR, "/dev/null");

# Vi skal skrive ut html
print "Content-type: text/html\n\n";

# Les konfigurasjonsfil inn i en assosiativ array
while (<FIL>) {
	@TMP=split(/\#/);
	@CONF{$TMP[0]} = $TMP[1];
}

&print_header;
&print_teknisk;
&print_footer;
exit;


sub print_header {
	print "
<html>
<head>
<title>
Teknisk Vedlikehold
</title>
<head>
<body bgcolor=#ffffff>
<hr size=1 noshade>
<h1>Teknisk vedlikehold av $CONF{'TITLE'}</h1>
<hr size=2 noshade>
";

	return
}

sub print_teknisk {
	# Skriv ut teknisk informasjon, s� som pather o.l.
	print "
<p>
<font size=+1>TEKNISK INFORMASJON:</font><p>
<blockquote>
<form method=\"POST\" action=\"change_cfg.cgi\">
<table border=0>
<tr>
<td width=30%  align=left>
Server root:
</td><td  align=left>
<input size=40 name=\"ROOT\" value=$CONF{'ROOT'}>
</td></tr>

<tr><td  align=left>
Dokument path:
</td><td  align=left>
<input size=40 name=\"LOCAL_PATH\" value=$CONF{'LOCAL_PATH'}>
</td></tr>
";

	print "
<tr><td  align=left>
Forside:
</td><td  align=left>
<input size=40 name=\"FRONTPAGE\" value=$CONF{'FRONTPAGE'}>
</td></tr>

<tr><td  align=left>
Produktbase:
</td><td  align=left>
<input size=40 name=\"PRODBASE\" value=$CONF{'PRODBASE'}>
</td></tr>

<tr><td  align=left>
Avdelingsbase:
</td><td  align=left>
<input size=40 name=\"AVDBASE\" value=$CONF{'AVDBASE'}>
</tr></td>
	";

	print "
<tr><td  align=left>
Omr�de for Gif-bilder:
</td><td  align=left>
<input size=40 name=\"GIFS_DIR\" value=$CONF{'GIFS_DIR'}>
</tr></td>

<tr><td  align=left>
Generering av sider:
</td><td  align=left>
<input size=40 name=\"PAGE_GENERATOR\" value=$CONF{'PAGE_GENERATOR'}>
</tr></td>

<tr><td  align=left>
Vise handlekurv:
</td><td  align=left>
<input size=40 name=\"GET_CONT\" value=$CONF{'GET_CONT'}>
</tr></td>
	";

	print "
<tr><td  align=left>
Kasse:
</td><td  align=left>
<input size=40 name=\"CHECK_OUT\" value=$CONF{'CHECK_OUT'}>
</tr></td>

<tr><td  align=left>
Bestillingsskjema:
</td><td  align=left>
<input size=40 name=\"ORDER_FORM\" value=$CONF{'ORDER_FORM'}>
</tr></td>

<tr><td  align=left>
Best. mailes til:
</td><td  align=left>
<input size=40 name=\"REQ_MAIL\" value=$CONF{'REQ_MAIL'}>
</tr></td>
</table>
</blockquote>
";

	print "
<INPUT TYPE=\"submit\" VALUE=\"Utf�r endringer\">
<INPUT TYPE=\"reset\" VALUE=\"Undo endringer\"><br>
</form>

	";

	return
}


sub print_footer {

	print "
<hr size=1 noshade>
<address>
Oslonett AS
</address>
<hr size=2 noshade>
</body>
</html>
	";

	return
}



