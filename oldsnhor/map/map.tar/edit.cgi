#!/local/bin/perl

$dir = "/local/www/map";
$urlprefix = "http://www2.oslonett.no/map";

$| = 1;  # flush
print "Content-type: text/html\n\n";

# print "<pre>\n";
# system "env";
# print "-----\n\n</pre>\n";

&die("No user name defined")
    unless length $ENV{REMOTE_USER};
$user = $ENV{REMOTE_USER};

for (split(/&/, $ENV{QUERY_STRING})) {
	($name, $val) = split(/=/, $_);
        $val =~ s/\+/ /g;
        $val =~ s/%([\da-f][\da-f])/pack("C",hex($1))/gei;
	#print "$name: $val\n" if length $val;
	$query{$name} = $val;
}

if (defined $query{"id"}) {
    $id = $query{"id"};
    $id =~ s/\.map$//;
    $map = "$dir/$id.map";
    if (-f $map) {
        print qq{<title>Edit mapfile</title>
<h1>Edit mapfile ($id)</h1>
<form action="new.cgi" method=POST>
<input type=hidden name=id value="$id">
<textarea name=map cols=60 rows=12>
};
        system "cat", $map;
	print qq{</textarea>
<p><input type=submit value="Update it!"

</form>
};	system "cat", "$dir/format.html"
    } else {
        print "<h2>No mapfile with ID=$id</h2>\n";
    }
    exit;
} else {
    print "<h2>Select a mapfile:</h2>\n";
    print "<ul>\n";
    opendir(DH, $dir) or &die("Can't open $dir: $!");
    foreach (sort readdir(DH)) {
	next unless /\.map$/;
        next unless /^$user-/o;
        print qq{<li> <a href="edit.cgi?id=$_">$_</a>\n};
    }
    print "</ul>\n";
    closedir(DH);
}

sub die
{
    print "<h2>Intern feil</h1> @_";
    print "</body>\n";
    exit;
}

